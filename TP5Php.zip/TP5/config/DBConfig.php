<?php

const DB_HOST="localhost";
const DB_Name="tp5";
const DB_Login="root";
const DB_Password="root";